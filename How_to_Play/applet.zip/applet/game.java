import processing.core.*; 
import processing.xml.*; 

import java.applet.*; 
import java.awt.Dimension; 
import java.awt.Frame; 
import java.awt.event.MouseEvent; 
import java.awt.event.KeyEvent; 
import java.awt.event.FocusEvent; 
import java.awt.Image; 
import java.io.*; 
import java.net.*; 
import java.text.*; 
import java.util.*; 
import java.util.zip.*; 
import java.util.regex.*; 

public class game extends PApplet {

//Please note - protagonist notKirby is also known as "Ball" throughout this code and commentary. Live free of perplexity!

PFont font;
boolean bounced = true; //Detect whether player has achieved the winning condition.
boolean direction = true; //Control which direction notKirby faces.
float resizer = 0.25f; //Use to scale notKirby's size as needed.
int currentLevel = 0; //Control the current level (game screen).
int msg = 1; //Control the display of messages and how they affect game play.
boolean next = true; //Control transition between messages and game play.
int fontsize = 24;
int textBackground = 0xff9FA1FA; //Background color of text boxes.
int textColor = 0;
boolean promptJump = false; //Prompt jumping at one point.
boolean noAdvance = false; //Prevent moving through messages at one point.
int jumpCounter = 0; //Tally jumps at one point.
boolean pressedV = false; //Check if V has been pressed.
boolean pressedVlevel = false; //Check if this is the level to press V.

notKirby notKirby; //Declare an instance of the protagonist object ("notKirby").
Level [] myLevels; //Declare an array of "Level" objects (which are themselves ArrayLists, "Inception"-style.)
boolean[] levelNew;

//_____________________________________________________________________________________________________________

public void setup() {
  size(800, 600);
  smooth();
  font = loadFont("font.vlw");

  myLevels = new Level[18]; //Initialize the number of levels in the brackets.
  myLevels[0] = new Level(0); //We initialize each element in the array, labeling each with the level number it represents and making it a level object. See the Level tab regarding the constructor.
  myLevels[1] = new Level(1);
  myLevels[2] = new Level(2);
  myLevels[3] = new Level(3);
  myLevels[4] = new Level(4);
  myLevels[5] = new Level(5);
  myLevels[6] = new Level(6);
  myLevels[7] = new Level(7);
  myLevels[8] = new Level(8);
  myLevels[9] = new Level(9);
  myLevels[10] = new Level(10);
  myLevels[11] = new Level(11);
  myLevels[12] = new Level(12);
  myLevels[13] = new Level(13);
  myLevels[14] = new Level(14);
  myLevels[15] = new Level(15);
  myLevels[16] = new Level(16);
  myLevels[17] = new Level(17);

  levelNew = new boolean[18]; //Use these booleans to test whether or not we are visiting a room for the first time.
  levelNew[0] = false;
  levelNew[1] = false;
  levelNew[2] = false;
  levelNew[3] = false;
  levelNew[4] = false;
  levelNew[5] = false;
  levelNew[6] = false;
  levelNew[7] = false;
  levelNew[8] = false;
  levelNew[9] = false;
  levelNew[10] = false;
  levelNew[11] = false;
  levelNew[12] = false;
  levelNew[13] = false;
  levelNew[14] = false;
  levelNew[15] = false;
  levelNew[16] = false;
  levelNew[17] = false;

  for (int i = 0; i < myLevels.length; i++) { //Use a for loop to iterate through each level in the array.
    myLevels[i].prep(); //Prepare every level to be drawn. We won't draw them all at once. Sorry.
  }
  notKirby = new notKirby(50, 600 - ((175 * resizer) / 2), 175, 200, color(0xffFF08F3)); //Create an instance of notKirby object using parameters entered in the constructor (see notKirby tab).
  notKirby.prep(); //Load notKirby's components.
}

//_____________________________________________________________________________________________________________

public void draw() {
  background(150);

  //if (currentLevel == (myLevels.length - 1)) {
  if (currentLevel == 11) {
    if (bounced == true) { //Did the player win?
      fill(255);
      text("Winner! You jumped this.", 115, 70); //Display winning text.
    }
    else if (bounced != true) { //The player hasn't won yet?
      fill(255);
      text("Can't jump this.", 135, 70); //Display other text.
    }
  }

  myLevels[currentLevel].display(); //Here's where things get awesome. We draw only the level in the array whose element label matches the value of the variable indicating the current level. If the current level is set at 2, we don't draw level 1 or level 3. Look, Ma, no for loop!
  //println("levelNew[0] = " + levelNew[0] + " levelNew[1] = " + levelNew[1]); //Debug.

  if (currentLevel < (myLevels.length - 1)) { //If the next level exists...
    if (bounced == true) { //If we are not on the 'winning' level, needing to win...
      stroke(255);
      strokeWeight(2);
      line((width - 50), (height - 25), (width - 25), (height - 25)); //With these three lines we draw an arrow pointing to the next screen.
      line((width - 25), (height - 25), (width - 35), (height - 35));
      line((width - 25), (height - 25), (width - 35), (height - 15));

      if (notKirby.xPos >= width-(notKirby.wide / 2)) { //Here we will transition between levels. If notKirby crosses the right edge of the screen...
        currentLevel++; //...switch to the next level...
        notKirby.xPos = (notKirby.wide / 2); //...and move notKirby to the other side of the screen so it looks like he really moved between screens.
        if (levelNew[currentLevel] == false) { //If we haven't visited this level before...
          next = true; //...prepare for new messages.
          msg = 1; //Ditto.
        }
      }
    }
  }

  if (currentLevel > 0) { //If the previous level exists...
    if (bounced == true) { //If we are not on the 'winning' level, needing to win...
      stroke(255);
      strokeWeight(2);
      line(50, (height - 25), 25, (height - 25)); //With these three lines we draw an arrow pointing to the next screen.
      line(25, (height - 25), 35, (height - 35));
      line(25, (height - 25), 35, (height - 15));

      if (notKirby.xPos < (notKirby.wide / 2)) { //Do the above going the other way. If notKirby crosses the left edge of the screen...
        currentLevel--; //...switch to the previous level...
        notKirby.xPos = width - (notKirby.wide / 2); //...and move notKirby to the other side of the screen so it looks like he really moved between screens.
      }
    }
  }

  notKirby.display(); //Draw notKirby! (by calling the function from the tab)
  notKirby.updateBall(); //Call the updateBall function from the notKirby tab.

  //println(currentLevel); //Debug.


  //Start of instructions___________________________________________________________________________//


  //Let's display some instructions. We'll draw text at different points on screen and colored backgrounds behind the text, and instruct the player to press ENTER to progress through the messages.
  textFont(font, fontsize);
  textAlign(CENTER);

  if (currentLevel == 0) { //First level.
    rectMode(CORNER);
    if (msg == 1) {
      noStroke(); 
      fill(textBackground); 
      rect(width/2-100, height/2-fontsize*5, 200, 75);
      fill(textColor); 
      text("Ah, there you are.", width/2, height/2-fontsize*4);
      textFont(font, fontsize/1.5f); 
      text("[Press ENTER]", width/2, height/2-fontsize*2);
    }
    else if (msg == 2) {
      noStroke(); 
      fill(textBackground); 
      rect(width/4-100, height/2+fontsize*2, 200, 100);
      fill(textColor); 
      textFont(font, fontsize/1.25f); 
      text("Oh, good. You know\nhow to follow orders.", width/4, height/2+fontsize*3);
      textFont(font, fontsize/1.5f); 
      text("[Press ENTER]", width/4, height/2+fontsize*6);
    }
    else if (msg == 3) {
      noStroke(); 
      fill(textBackground); 
      rect(width/1.25f-115, height-(height/5)-fontsize*2, 225, 100);
      textFont(font, fontsize*2); 
      fill(textColor); 
      text("I like that.", width/1.25f, height-(height/5));
      textFont(font, fontsize/1.5f); 
      text("[Press ENTER]", width/1.25f, height-(height/5)+fontsize*2);
    }
    else if (msg == 4) {
      noStroke(); 
      fill(textBackground); 
      rect(85, height-100, 175, 50+fontsize);
      textFont(font, fontsize*1.25f); 
      fill(textColor); 
      text("Let's begin.", 175, height-100+fontsize);
      textFont(font, fontsize/1.5f); 
      text("[Press ENTER]", 175, height-100+fontsize*3);
    }
    else if (msg == 5) { //In this case we are not moving between screens by controlling notKirby so we handle the transition here.
      levelNew[currentLevel] = true; //We have now read the messages here so we set the variable to true so the messages don't repeat if we return to this screen.
      currentLevel++;
      msg = 1;
    }
  }

  if (currentLevel == 1) { //Second level.
    //rectMode(CENTER);
    if (msg == 1) {
      noStroke(); 
      fill(textBackground); 
      rect(width/2, height/7+fontsize/2, 215, 50+fontsize*2);
      textFont(font, fontsize*1.25f); 
      fill(textColor); 
      text("This is a 'game.'", width/2, height/7);
      textFont(font, fontsize/1.5f); 
      text("[Press ENTER]", width/2, height/7+fontsize*2);
    }
    else if (msg == 2) {
      noStroke(); 
      fill(textBackground); 
      rect(width/2, height/3+fontsize, 260, fontsize*5);
      textFont(font, fontsize); 
      fill(textColor); 
      text("The purpose of a 'game'\nis to have 'fun.'", width/2, height/3);
      textFont(font, fontsize/1.5f); 
      text("[Press ENTER]", width/2, height/3+fontsize*3);
    }
    else if (msg == 3) {
      noStroke(); 
      fill(textBackground); 
      rect(width/2, height/2+fontsize*2+5, 260, fontsize*4+10);
      textFont(font, fontsize*0.75f); 
      fill(textColor); 
      text("'Fun' is what you have\nwhen you're being 'useless.'", width/2, height/2+fontsize);
      textFont(font, fontsize/1.5f); 
      text("[Press ENTER]", width/2, height/2+fontsize*4);
    }
    else if (msg == 4) {
      noStroke(); 
      fill(textBackground); 
      rect(width/2, height-fontsize*4, 315, fontsize*6+15);
      textFont(font, fontsize*2); 
      fill(textColor); 
      text("Who's ready\nfor some fun!?", width/2, height-fontsize*5);
      textFont(font, fontsize/1.5f); 
      text("[Press ENTER]", width/2, height-fontsize);
    }
    else if (msg == 5) {
      levelNew[currentLevel] = true; //We have now read the messages here so we set the variable to true so the messages don't repeat if we return to this screen.
      currentLevel++;
      msg = 1;
    }
  }

  if (currentLevel == 2) {
    if (msg == 1) {
      noStroke();
      fill(textBackground); 
      rect(width/2, height/2, 315, fontsize*6+15);
      textFont(font, fontsize); 
      fill(textColor); 
      text("This is your 'avatar.'", width/2, height/2);
      textFont(font, fontsize/1.5f); 
      text("[Press ENTER]", width/2, height/2+fontsize*2);
      //draw arrow
    }
    if (msg == 2) {
      noStroke();
      fill(textBackground); 
      rect(width/2, height/2, 315, fontsize*6+15);
      textFont(font, fontsize); 
      fill(textColor); 
      text("You are not the same as it.", width/2, height/2);
      textFont(font, fontsize/1.5f); 
      text("[Press ENTER]", width/2, height/2+fontsize*2);
    }
    if (msg == 3) {
      noStroke();
      fill(textBackground); 
      rect(width/2, height/2, 315, fontsize*6+15);
      textFont(font, fontsize); 
      fill(textColor); 
      text("But it does represent\nyou in the game.", width/2, height/2);
      textFont(font, fontsize/1.5f); 
      text("[Press ENTER]", width/2, height/2+fontsize*2);
    }
    if (msg == 4) {
      noStroke();
      fill(textBackground); 
      rect(width/2, height/2, 315, fontsize*6+15);
      textFont(font, fontsize); 
      fill(textColor); 
      text("With a 90% increase\nin adorableness.", width/2, height/2);
      textFont(font, fontsize/1.5f); 
      text("[Press ENTER]", width/2, height/2+fontsize*2);
    }
    if (msg == 5) {
      levelNew[currentLevel] = true;
      currentLevel++;
      msg = 1;
    }
  }

  if (currentLevel == 3) {
    if (msg == 1) {
      noStroke();
      fill(textBackground); 
      rect(width/2, height/2, 315, fontsize*6+15);
      textFont(font, fontsize); 
      fill(textColor); 
      text("This world is flat.", width/2, height/2);
      textFont(font, fontsize/1.5f); 
      text("[Press ENTER]", width/2, height/2+fontsize*2);
      //draw arrow
    }
    if (msg == 2) {
      noStroke();
      fill(textBackground); 
      rect(width/2, height/2, 315, fontsize*6+15);
      textFont(font, fontsize); 
      fill(textColor); 
      text("Not like your outdated\ngeographic theories.", width/2, height/2);
      textFont(font, fontsize/1.5f); 
      text("[Press ENTER]", width/2, height/2+fontsize*2);
    }
    if (msg == 3) {
      noStroke();
      fill(textBackground); 
      rect(width/2, height/2, 315, fontsize*6+15);
      textFont(font, fontsize); 
      fill(textColor); 
      text("But vertically flat.", width/2, height/2);
      textFont(font, fontsize/1.5f); 
      text("[Press ENTER]", width/2, height/2+fontsize*2);
    }
    if (msg == 4) {
      levelNew[currentLevel] = true;
      currentLevel++;
      msg = 1;
    }
  }

  if (currentLevel == 4) {
    if (msg == 1) {
      noStroke();
      fill(textBackground); 
      rect(width/2, height/2, 315, fontsize*6+15);
      textFont(font, fontsize); 
      fill(textColor); 
      text("There is left.", width/2, height/2);
      textFont(font, fontsize/1.5f); 
      text("[Press ENTER]", width/2, height/2+fontsize*2);
    }
    if (msg == 2) {
      noStroke();
      fill(textBackground); 
      rect(width/2, height/2, 315, fontsize*6+15);
      textFont(font, fontsize); 
      fill(textColor); 
      text("And there is right.", width/2, height/2);
      textFont(font, fontsize/1.5f); 
      text("[Press ENTER]", width/2, height/2+fontsize*2);
    }
    if (msg == 3) {
      noStroke();
      fill(textBackground); 
      rect(width/2, height/2, 315, fontsize*6+15);
      textFont(font, fontsize); 
      fill(textColor); 
      text("There is up.", width/2, height/2);
      textFont(font, fontsize/1.5f); 
      text("[Press ENTER]", width/2, height/2+fontsize*2);
    }
    if (msg == 4) {
      noStroke();
      fill(textBackground); 
      rect(width/2, height/2, 315, fontsize*6+15);
      textFont(font, fontsize); 
      fill(textColor); 
      text("And there is down.", width/2, height/2);
      textFont(font, fontsize/1.5f); 
      text("[Press ENTER]", width/2, height/2+fontsize*2);
    }
    if (msg == 5) {
      noStroke();
      fill(textBackground); 
      rect(width/2, height/2, 315, fontsize*6+15);
      textFont(font, fontsize); 
      fill(textColor); 
      text("Two dimensions.", width/2, height/2);
      textFont(font, fontsize/1.5f); 
      text("[Press ENTER]", width/2, height/2+fontsize*2);
    }
    if (msg == 6) {
      noStroke();
      fill(textBackground); 
      rect(width/2, height/2, 315, fontsize*6+15);
      textFont(font, fontsize); 
      fill(textColor); 
      text("There is no depth\n\nin this game.", width/2, height/2);
      textFont(font, fontsize/1.5f); 
      text("[Press ENTER]", width/2, height/2+fontsize*2);
    }
    if (msg == 7) {
      levelNew[currentLevel] = true;
      currentLevel++;
      msg = 1;
    }
  }

  if (currentLevel == 5) {
    if (msg == 1) {
      noStroke();
      fill(textBackground); 
      rect(width/2, height/2, 315, fontsize*6+15);
      textFont(font, fontsize); 
      fill(textColor); 
      text("You can move your avatar\nif you know the secret.", width/2, height/2);
      textFont(font, fontsize/1.5f); 
      text("[Press ENTER]", width/2, height/2+fontsize*2);
    }
    if (msg == 2) {
      noStroke();
      fill(textBackground); 
      rect(width/2, height/2, 315, fontsize*6+15);
      textFont(font, fontsize); 
      fill(textColor); 
      text("Here is the secret.", width/2, height/2);
      textFont(font, fontsize/1.5f); 
      text("[Press ENTER]", width/2, height/2+fontsize*2);
    }
    if (msg == 3) {
      noStroke();
      fill(textBackground); 
      rect(width/2, height/2, 315, fontsize*6+15);
      textFont(font, fontsize); 
      fill(textColor); 
      text("Find the key with\na right-pointing arrow.", width/2, height/2);
      textFont(font, fontsize/1.5f); 
      text("[Press ENTER]", width/2, height/2+fontsize*2);
    }
    if (msg == 4) {
      noStroke();
      fill(textBackground); 
      rect(width/2, height/2, 315, fontsize*6+15);
      textFont(font, fontsize); 
      fill(textColor); 
      text("I call it the\n'right arrow key.'", width/2, height/2);
      textFont(font, fontsize/1.5f); 
      text("[Press ENTER]", width/2, height/2+fontsize*2);
    }
    if (msg == 5) {
      noStroke();
      fill(textBackground); 
      rect(width/2, height/2, 315, fontsize*6+15);
      textFont(font, fontsize); 
      fill(textColor); 
      text("Press it to move right.", width/2, height/2);
      textFont(font, fontsize/1.5f); 
      text("[Press ENTER]", width/2, height/2+fontsize*2);
    }
    if (msg == 6) {
      next = false;
      levelNew[currentLevel] = true;
      msg = 0;
    }
  }

  if (currentLevel == 6) {
    if (msg == 1) {
      noStroke();
      fill(textBackground); 
      rect(width/2, height/2, 315, fontsize*6+15);
      textFont(font, fontsize); 
      fill(textColor); 
      text("There is a 'left-\narrow key,' too.", width/2, height/2);
      textFont(font, fontsize/1.5f); 
      text("[Press ENTER]", width/2, height/2+fontsize*2);
    }
    if (msg == 2) {
      noStroke();
      fill(textBackground); 
      rect(width/2, height/2, 315, fontsize*6+15);
      textFont(font, fontsize); 
      fill(textColor); 
      text("Maybe you knew this?", width/2, height/2);
      textFont(font, fontsize/1.5f); 
      text("[Press ENTER]", width/2, height/2+fontsize*2);
    }
    if (msg == 3) {
      noStroke();
      fill(textBackground); 
      rect(width/2, height/2, 315, fontsize*6+15);
      textFont(font, fontsize); 
      fill(textColor); 
      text("I'll bet you can guess\nwhat that does.", width/2, height/2);
      textFont(font, fontsize/1.5f); 
      text("[Press ENTER]", width/2, height/2+fontsize*2);
    }
    if (msg == 4) {
      next = false;
      levelNew[currentLevel] = true;
      msg = 0;
    }
  }

  if (currentLevel == 7) {
    if (msg == 1) {
      noStroke();
      fill(textBackground); 
      rect(width/2, height/2, 315, fontsize*6+15);
      textFont(font, fontsize); 
      fill(textColor); 
      text("The 'up-' and 'down-\narrow keys,' however", width/2, height/2);
      textFont(font, fontsize/1.5f); 
      text("[Press ENTER]", width/2, height/2+fontsize*2);
    }
    if (msg == 2) {
      noStroke();
      fill(textBackground); 
      rect(width/2, height/2, 315, fontsize*6+15);
      textFont(font, fontsize); 
      fill(textColor); 
      text("do not do what you expect.", width/2, height/2);
      textFont(font, fontsize/1.5f); 
      text("[Press ENTER]", width/2, height/2+fontsize*2);
    }
    if (msg == 3) {
      noStroke();
      fill(textBackground); 
      rect(width/2, height/2, 315, fontsize*6+15);
      textFont(font, fontsize); 
      fill(textColor); 
      text("Ha ha.", width/2, height/2);
      textFont(font, fontsize/1.5f); 
      text("[Press ENTER]", width/2, height/2+fontsize*2);
    }
    if (msg == 4) {
      noStroke();
      fill(textBackground); 
      rect(width/2, height/2, 315, fontsize*6+15);
      textFont(font, fontsize); 
      fill(textColor); 
      text("You still need\nthe secret.", width/2, height/2);
      textFont(font, fontsize/1.5f); 
      text("[Press ENTER]", width/2, height/2+fontsize*2);
    }
    if (msg == 5) {
      next = false;
      levelNew[currentLevel] = true;
      msg = 0;
    }
  }

  if (currentLevel == 8) {
    if (msg == 1) {
      noStroke();
      fill(textBackground); 
      rect(width/2, height/2, 315, fontsize*6+15);
      textFont(font, fontsize); 
      fill(textColor); 
      text("Here is the secret.", width/2, height/2);
      textFont(font, fontsize/1.5f); 
      text("[Press ENTER]", width/2, height/2+fontsize*2);
    }
    if (msg == 2) {
      noStroke();
      fill(textBackground); 
      rect(width/2, height/2, 315, fontsize*6+15);
      textFont(font, fontsize); 
      fill(textColor); 
      text("Press the 'SPACE\nBAR' to 'jump.'", width/2, height/2);
      textFont(font, fontsize/1.5f); 
      text("[Press ENTER]", width/2, height/2+fontsize*2);
    }
    if (msg == 3) {
      noStroke();
      fill(textBackground); 
      rect(width/2, height/2, 315, fontsize*6+15);
      textFont(font, fontsize); 
      fill(textColor); 
      text("I hope you know\nwhat that is.", width/2, height/2);
      textFont(font, fontsize/1.5f); 
      text("[Press ENTER]", width/2, height/2+fontsize*2);
    }
    if (msg == 4) {
      noStroke();
      fill(textBackground); 
      rect(width/2, height/2, 315, fontsize*6+15);
      textFont(font, fontsize); 
      fill(textColor); 
      text("('SPACE BAR' and 'jumping,'\nthat is.)", width/2, height/2);
      textFont(font, fontsize/1.5f); 
      text("[Press ENTER]", width/2, height/2+fontsize*2);
    }
    if (msg == 5) {
      noStroke();
      fill(textBackground); 
      rect(width/2, height/2, 315, fontsize*6+15);
      textFont(font, fontsize); 
      fill(textColor); 
      text("Try it now.", width/2, height/2);
      textFont(font, fontsize/1.5f); 
      text("[Press ENTER]", width/2, height/2+fontsize*2);
      promptJump = true; //Enable jumping.
    }
    if (msg == 6) {
      noAdvance = true;
      if (jumpCounter >= 3) {
        noStroke();
        fill(textBackground); 
        rect(width/2, height/2, 315, fontsize*6+15);
        textFont(font, fontsize); 
        fill(textColor); 
        text("Ha ha! Look at your avatar's\nlittle arm flip up and down!", width/2, height/2);
        textFont(font, fontsize/1.5f); 
        text("[Press ENTER]", width/2, height/2+fontsize*2);
        noAdvance = false;
      }
    }
    if (msg == 7) {
      jumpCounter = 0;
      noStroke();
      fill(textBackground); 
      rect(width/2, height/2, 315, fontsize*6+15);
      textFont(font, fontsize); 
      fill(textColor); 
      text("SO CUTE.", width/2, height/2);
      textFont(font, fontsize/1.5f); 
      text("[Press ENTER]", width/2, height/2+fontsize*2);
    }
    if (msg == 8) {
      promptJump = false;
      next = false;
      levelNew[currentLevel] = true;
      msg = 0;
    }
  }

  if (currentLevel == 9) {
    if (msg == 1) {
      pressedVlevel = true;
      noStroke();
      fill(textBackground); 
      rect(width/2, height/2, 315, fontsize*6+15);
      textFont(font, fontsize); 
      fill(textColor); 
      text("Whatever you do,\ndon't press [v]!", width/2, height/2);
      textFont(font, fontsize/1.5f); 
      text("[Press ENTER]", width/2, height/2+fontsize*2);
    }
    if (msg == 2) {
      noAdvance = true;
      if (pressedV == true) {
        noStroke();
        fill(textBackground); 
        rect(width/2, height/2, 315, fontsize*6+15);
        textFont(font, fontsize); 
        fill(textColor); 
        text("Just kidding.\nJust testing you.", width/2, height/2);
        textFont(font, fontsize/1.5f); 
        text("[Press ENTER]", width/2, height/2+fontsize*2);
        noAdvance = false;
      }
    }
    if (msg == 3) {
      pressedV = false;
      pressedVlevel = false;
      noStroke();
      fill(textBackground); 
      rect(width/2, height/2, 315, fontsize*6+15);
      textFont(font, fontsize); 
      fill(textColor); 
      text("You failed.", width/2, height/2);
      textFont(font, fontsize/1.5f); 
      text("[Press ENTER]", width/2, height/2+fontsize*2);
    }
    if (msg == 4) {
      noStroke();
      fill(textBackground); 
      rect(width/2, height/2, 315, fontsize*6+15);
      textFont(font, fontsize); 
      fill(textColor); 
      text("LOL ha ha.", width/2, height/2);
      textFont(font, fontsize/1.5f); 
      text("[Press ENTER]", width/2, height/2+fontsize*2);
    }
    if (msg == 5) {
      noStroke();
      fill(textBackground); 
      rect(width/2, height/2, 315, fontsize*6+15);
      textFont(font, fontsize); 
      fill(textColor); 
      text("Alright, let's get\ndown to business.", width/2, height/2);
      textFont(font, fontsize/1.5f); 
      text("[Press ENTER]", width/2, height/2+fontsize*2);
    }
    if (msg == 6) {
      next = false;
      levelNew[currentLevel] = true;
      msg = 0;
    }
  }

  if (currentLevel == 10) {
    if (msg == 1) {
      noStroke();
      fill(textBackground); 
      rect(width/2, height/2, 315, fontsize*6+15);
      textFont(font, fontsize); 
      fill(textColor); 
      text("This is a 'platform.'", width/2, height/2);
      textFont(font, fontsize/1.5f);
      text("[Press ENTER]", width/2, height/2+fontsize*2);
      //draw arrow
    }
    if (msg == 2) {
      noStroke();
      fill(textBackground); 
      rect(width/2, height/2, 315, fontsize*6+15);
      textFont(font, fontsize); 
      fill(textColor); 
      text("Your avatar can\njump on the platform.", width/2, height/2);
      textFont(font, fontsize/1.5f); 
      text("[Press ENTER]", width/2, height/2+fontsize*2);
    }
    if (msg == 3) {
      noStroke();
      fill(textBackground); 
      rect(width/2, height/2, 315, fontsize*6+15);
      textFont(font, fontsize); 
      fill(textColor); 
      text("If you are lucky it\nwill hold weight.", width/2, height/2);
      textFont(font, fontsize/1.5f); 
      text("[Press ENTER]", width/2, height/2+fontsize*2);
    }
    if (msg == 4) {
      noStroke();
      fill(textBackground); 
      rect(width/2, height/2, 315, fontsize*6+15);
      textFont(font, fontsize); 
      fill(textColor); 
      text("Ha ha, just kidding.", width/2, height/2);
      textFont(font, fontsize/1.5f); 
      text("[Press ENTER]", width/2, height/2+fontsize*2);
    }
    if (msg == 5) {
      noStroke();
      fill(textBackground); 
      rect(width/2, height/2, 315, fontsize*6+15);
      textFont(font, fontsize); 
      fill(textColor); 
      text("All platforms are\n100% reliable.", width/2, height/2);
      textFont(font, fontsize/1.5f); 
      text("[Press ENTER]", width/2, height/2+fontsize*2);
    }
    if (msg == 6) {
      next = false;
      levelNew[currentLevel] = true;
      msg = 0;
    }
  }

  if (currentLevel == 11) {
    if (msg == 1) {
      bounced = false;
      noStroke();
      fill(textBackground); 
      rect(width/2, height/2, 315, fontsize*6+15);
      textFont(font, fontsize); 
      fill(textColor); 
      text("There are multiple platforms.", width/2, height/2);
      textFont(font, fontsize/1.5f); 
      text("[Press ENTER]", width/2, height/2+fontsize*2);
    }
    if (msg == 2) {
      noStroke();
      fill(textBackground); 
      rect(width/2, height/2, 315, fontsize*6+15);
      textFont(font, fontsize); 
      fill(textColor); 
      text("Make your way to\nthe top platform.", width/2, height/2);
      textFont(font, fontsize/1.5f); 
      text("[Press ENTER]", width/2, height/2+fontsize*2);
    }
    if (msg == 3) {
      noStroke();
      fill(textBackground); 
      rect(width/2, height/2, 315, fontsize*6+15);
      textFont(font, fontsize); 
      fill(textColor); 
      text("See how it mocks you?", width/2, height/2);
      textFont(font, fontsize/1.5f); 
      text("[Press ENTER]", width/2, height/2+fontsize*2);
    }
    if (msg == 4) {
      noStroke();
      fill(textBackground); 
      rect(width/2, height/2, 315, fontsize*6+15);
      textFont(font, fontsize); 
      fill(textColor); 
      text("Don't put up with mockery!", width/2, height/2);
      textFont(font, fontsize/1.5f); 
      text("[Press ENTER]", width/2, height/2+fontsize*2);
    }
    if (msg == 5) {
      next = false;
      levelNew[currentLevel] = true;
      msg = 0;
    }
    if (msg == 6) {
      next = true;
      noStroke();
      fill(textBackground); 
      rect(width/2, height/2, 315, fontsize*6+15);
      textFont(font, fontsize); 
      fill(textColor); 
      text("Well done.", width/2, height/2);
      textFont(font, fontsize/1.5f); 
      text("[Press ENTER]", width/2, height/2+fontsize*2);
    }
    if (msg == 7) {
      next = false;
      msg = 0;
    }
  }

  if (currentLevel == 12) {
    if (msg == 1) {
      noStroke();
      fill(textBackground); 
      rect(width/2, height/2, 315, fontsize*6+15);
      textFont(font, fontsize); 
      fill(textColor); 
      text("Wait\u2026what's that number\ndoing up there?", width/2, height/2);
      textFont(font, fontsize/1.5f); 
      text("[Press ENTER]", width/2, height/2+fontsize*2);
    }
    if (msg == 2) {
      next = false;
      levelNew[currentLevel] = true;
      msg = 0;
    }
  }

  if (currentLevel == 13) {
    if (msg == 1) {
      noStroke();
      fill(textBackground); 
      rect(width/2, height/2, 315, fontsize*6+15);
      textFont(font, fontsize); 
      fill(textColor); 
      text("It looks like a score.", width/2, height/2);
      textFont(font, fontsize/1.5f); 
      text("[Press ENTER]", width/2, height/2+fontsize*2);
    }
    if (msg == 2) {
      next = false;
      levelNew[currentLevel] = true;
      msg = 0;
    }
  }

  if (currentLevel == 14) {
    if (msg == 1) {
      noStroke();
      fill(textBackground); 
      rect(width/2, height/2, 315, fontsize*6+15);
      textFont(font, fontsize); 
      fill(textColor); 
      text("I don't remember\nany scoring system.", width/2, height/2);
      textFont(font, fontsize/1.5f); 
      text("[Press ENTER]", width/2, height/2+fontsize*2);
    }
    if (msg == 2) {
      next = false;
      levelNew[currentLevel] = true;
      msg = 0;
    }
  }

  if (currentLevel == 15) {
    if (msg == 1) {
      noStroke();
      fill(textBackground); 
      rect(width/2, height/2, 315, fontsize*6+15);
      textFont(font, fontsize); 
      fill(textColor); 
      text("Wait a minute...", width/2, height/2);
      textFont(font, fontsize/1.5f); 
      text("[Press ENTER]", width/2, height/2+fontsize*2);
    }
    if (msg == 2) {
      next = false;
      levelNew[currentLevel] = true;
      msg = 0;
    }
  }

  if (currentLevel == 16) {
    if (msg == 1) {
      noStroke();
      fill(textBackground); 
      rect(width/2, height/2, 315, fontsize*6+15);
      textFont(font, fontsize); 
      fill(textColor); 
      text("Are these the right...", width/2, height/2);
      textFont(font, fontsize/1.5f); 
      text("[Press ENTER]", width/2, height/2+fontsize*2);
    }
    if (msg == 2) {
      next = false;
      levelNew[currentLevel] = true;
      msg = 0;
    }
  }

  if (currentLevel == 17) {
    if (msg == 1) {
      noStroke();
      fill(textBackground); 
      rect(width/2, height/2, 315, fontsize*6+15);
      textFont(font, fontsize); 
      fill(textColor); 
      text("These are the\nwrong instructions.", width/2, height/2);
      textFont(font, fontsize/1.5f); 
      text("[Press ENTER]", width/2, height/2+fontsize*2);
    }
    if (msg == 2) {
      noStroke();
      fill(textBackground); 
      rect(width/2, height/2, 315, fontsize*6+15);
      textFont(font, fontsize); 
      fill(textColor); 
      text("I think they're\nfor another game.", width/2, height/2);
      textFont(font, fontsize/1.5f); 
      text("[Press ENTER]", width/2, height/2+fontsize*2);
    }
    if (msg == 3) {
      noStroke();
      fill(textBackground); 
      rect(width/2, height/2, 315, fontsize*6+15);
      textFont(font, fontsize); 
      fill(textColor); 
      text("LOL", width/2, height/2);
      textFont(font, fontsize/1.5f); 
      text("[Press ENTER]", width/2, height/2+fontsize*2);
    }
    if (msg == 4) {
      noStroke();
      fill(textBackground); 
      rect(width/2, height/2, 315, fontsize*6+15);
      textFont(font, fontsize); 
      fill(textColor); 
      text("Alright,\n\nyou're on your own.", width/2, height/2);
      textFont(font, fontsize/1.5f); 
      text("[Press ENTER]", width/2, height/2+fontsize*2);
    }
    if (msg == 5) {
      noStroke();
      fill(textBackground); 
      rect(width/2, height/2, 315, fontsize*6+15);
      textFont(font, fontsize); 
      fill(textColor); 
      text("Later.", width/2, height/2);
      textFont(font, fontsize/1.5f); 
      text("[Press ENTER]", width/2, height/2+fontsize*2);
    }
    if (msg == 6) {
      next = false;
      levelNew[currentLevel] = true;
      msg = 0;
    }
  }

  if (currentLevel > 17) {
    /*
    if (msg == 1) {
     noStroke();
     fill(textBackground); 
     rect(width/2, height/2, 315, fontsize*6+15);
     textFont(font, fontsize); 
     fill(textColor); 
     text("", width/2, height/2);
     textFont(font, fontsize/1.5); 
     text("[Press ENTER]", width/2, height/2+fontsize*2);
     }
     */
    next = false;
    levelNew[currentLevel] = true;
    msg = 0;
  }

  //End of instructions___________________________________________________________________________//
}

//_____________________________________________________________________________________________________________

public void keyPressed() {
  if (key=='1') { //Debug.
    if (currentLevel > 0) { //If previous level exists...
      currentLevel--; //...switch to previous level.
    }
  }

  if (key=='2') { //Debug.
    if (currentLevel < (myLevels.length - 1)) { //If next level exists...
      currentLevel++; //...switch to next level.
    }
  }

  if (key=='0') { //Debug.
    msg--;
  }

  if (key=='v' || key=='V') { //Debug.
    if (pressedVlevel == true) {
      pressedV = true;
    }
  }

  if (keyCode==ENTER || keyCode==RETURN) { //Let's advance the text boxes.
    if (noAdvance == false) { //Assuming it is permitted.
      if (msg >= 1) { //If there's a message on screen...
        if (next == true) { //...and if there are more messages to come...
          msg++; //...advance to the next message.
        }
        else {
          msg = 0; //Turn off messages (thereby enabling movement).
        }
      }
    }
  }

  //Let's control the ball. Many, MANY thanks to Ramiro Corbetta and his Dorkshop on Intro to Game Programming for this method of controlling movement through booleans (resulting in much more fluid control and recognition of multiple buttons at once).

  if (promptJump == true) { //Special jump instructions for if jumping is prompted.
    if (key==' ') { //If the player presses the Space Bar...
      if (notKirby.yPos >= height - (notKirby.tall / 2)) { //...and if the ball is on the ground...
        notKirby.jump = true; //...enable jumping.
        jumpCounter ++;
      }
      else for (int i = 0; i < myLevels[currentLevel].myPlats.size(); i++) { //OK, this is where things get really awesome (and really complicated). It's time for collision detection - super cool and super important! Each level is an ArrayList composed of varying numbers of Platform objects. We use a for loop to count how many platforms there are in the ArrayList for the current level, then iterate through those platforms. We are going to check the ball's position relative to each Platform in the ArrayList.
        Platform myPlatform = myLevels[currentLevel].myPlats.get(i); //ArrayLists are weird (and cool). They don't necessarily know what kind of information they hold in their elements. In order to use if statements to check notKirby's position relative to each platform, we have to give each platform an identity, which we do by naming it as a platform ("myPlatform" in this case) and assigning it the current value of i. In other words, this statement allows us to pull one of the objects in the ArrayList so we can refer to it in the following statements.
        if ((notKirby.xPos + (notKirby.wide / 2) >= myPlatform.xPos) && (notKirby.xPos - (notKirby.wide / 2) <= (myPlatform.xPos + myPlatform.platWidth))) { //At each value of i (aka ArrayList element in this case), is the ball's xPos within the width of the platform at that element?
          if ((notKirby.yPos + (notKirby.tall / 2) >= myPlatform.yPos) && (notKirby.yPos + (notKirby.tall / 2) <= (myPlatform.yPos + notKirby.depth))) { //Assuming we got a positive result above, is the ball's yPos within the upper part of the platform at that element?
            notKirby.jump = true; //If yes to all the above, enable jumping.
            jumpCounter ++;
          }
        }
      }
    }
  }

  if (msg <= 0) { //If there are no messages on screen, proceed.
    if (keyCode==RIGHT) { //If the player presses the right-directional arrow key...
      notKirby.R = true; //...enable movement right...
      direction=true; //...and face right.
    }
    if (keyCode==LEFT) { //If the player presses the left-directional arrow key...
      notKirby.L = true; //...enable movement left...
      direction=false; //...and face left.
    }
    if (key==' ') { //If the player presses the Space Bar...
      if (notKirby.yPos >= height - (notKirby.tall / 2)) { //...and if the ball is on the ground...
        notKirby.jump = true; //...enable jumping.
      }
      else for (int i = 0; i < myLevels[currentLevel].myPlats.size(); i++) { //OK, this is where things get really awesome (and really complicated). It's time for collision detection - super cool and super important! Each level is an ArrayList composed of varying numbers of Platform objects. We use a for loop to count how many platforms there are in the ArrayList for the current level, then iterate through those platforms. We are going to check the ball's position relative to each Platform in the ArrayList.
        Platform myPlatform = myLevels[currentLevel].myPlats.get(i); //ArrayLists are weird (and cool). They don't necessarily know what kind of information they hold in their elements. In order to use if statements to check notKirby's position relative to each platform, we have to give each platform an identity, which we do by naming it as a platform ("myPlatform" in this case) and assigning it the current value of i. In other words, this statement allows us to pull one of the objects in the ArrayList so we can refer to it in the following statements.
        if ((notKirby.xPos + (notKirby.wide / 2) >= myPlatform.xPos) && (notKirby.xPos - (notKirby.wide / 2) <= (myPlatform.xPos + myPlatform.platWidth))) { //At each value of i (aka ArrayList element in this case), is the ball's xPos within the width of the platform at that element?
          if ((notKirby.yPos + (notKirby.tall / 2) >= myPlatform.yPos) && (notKirby.yPos + (notKirby.tall / 2) <= (myPlatform.yPos + notKirby.depth))) { //Assuming we got a positive result above, is the ball's yPos within the upper part of the platform at that element?
            notKirby.jump = true; //If yes to all the above, enable jumping.
          }
        }
      }
    }
  }
}

//_____________________________________________________________________________________________________________

public void keyReleased() { //We use these statements to stop movement when the player releases the key. Otherwise notKirby would just keep groovin' in the same direction until he runs into a wall. You jerk.
  if (keyCode==RIGHT) {
    notKirby.R = false;
  }
  if (keyCode==LEFT) {
    notKirby.L = false;
  }
}

class Level { //Are you ready to GET CRAZY????
  int thisLevel; //This is not the crazy part. We will use this variable to label each instance as a particular level.
  ArrayList<Platform> myPlats; //Time for an ArrayList of platforms! We declare and name it. The "<Platform>" is to tell the ArrayList what kind of object it is storing, since it doesn't know otherwise.

  Level(int _thisLevel) { //Here is the constructor for the Level object. We use variable "_thisLevel" so that when we create an instance of the Level object in the main tab, we can distinguish it from other Level objects without giving it a different name. We use the variable below to draw different sets of platforms.
    thisLevel = _thisLevel; //Here we set "_thisLevel" (which exists only inside the constructor) equal to the variable we created above. This way we can use the number we enter into the constructor in contexts outside the constructor, like below.
  }

  public void prep() { //Aw yeah. Things are about to get to the CRAZY I mentioned earlier.
    myPlats = new ArrayList<Platform>(); //Here we initialize the ArrayList. ArrayLists don't have a fixed size, so we don't have to give a number in brackets like in arrays. Hurray! The "<Platform>" serves the same purpose here as it did above - identifying to the ArrayList what kind of object it's storing. I'm not sure why we need to say this twice, but hey. As long as it works, amirite?
    if (thisLevel == 1) { //Yeah, baby. Here's how we create different levels and tell them apart. We create all these levels, identified by their thisLevel value. They're all ready to go from the get-go. But we only draw one at a time.
      myPlats.add(new Platform(100, 200, 80, 20));
      myPlats.add(new Platform(100, 400, 80, 20));
      myPlats.add(new Platform(width-100, 200, 80, 20));
      myPlats.add(new Platform(width-100, 400, 80, 20));
    }
    else if (thisLevel == 0) { //A third level? CRAZY.
      myPlats.add(new Platform(165, 200, 80, 20));
      myPlats.add(new Platform(365, 300, 80, 20));
      myPlats.add(new Platform(565, 200, 80, 20));
    }
    else if (thisLevel == 10) {
      myPlats.add(new Platform(165, height-100, 200, 20));
    }
    else if (thisLevel == 11) {
      myPlats.add(new Platform(165, height-100, 150, 20));
    }
    else if (thisLevel >= 2 && thisLevel != 11 && thisLevel != 10) {
    }
  }

  public void display() {
    for (int i = 0; i < myPlats.size(); i++) { //Here we use a for loop to iterate through all the platforms in the ArrayList. We use i to identify which element we are looking at. Note that we use "size()" instead of "length," because ArrayList has different syntax than array.
      Platform myPlatform = myPlats.get(i); //As on the main tab, we pull an object from the ArrayList so we can do something with it.
      myPlatform.drawPlatform(); //Call the drawPlatform function from the Platform tab using the specific parameters for this value of i (which is a specific element in the ArrayList).
      //fill(255); text(i, myPlatform.xPos + (myPlatform.platWidth / 2), myPlatform.yPos + (myPlatform.platHeight / 1.5)); //Debug - print the name of the element on the Platform drawn in that element, so we can easily tell which Platform is which.
    }
  }
}

//Please note - protagonist notKirby is also known as "Ball" throughout this code and commentary. Live free of perplexity!

class Platform { //Make a class called "Platform."
  float xPos; //Control horizontal position.
  float yPos; //Control vertical position.
  float platWidth; //Control width of object.
  float platHeight; //Control height of object.

  Platform(float x, float y, float w, float h) { //This is the constructor for the Platform object. See the note about constructors and local versus global variables on the Level tab.
    xPos = x;
    yPos = y;
    platWidth = w;
    platHeight = h;
  }

  public void drawPlatform() {
    rectMode(CORNER);
    noFill();
    stroke(255); //Give a white outline to objects.
    strokeWeight(2); //Thicken the outline.
    rect(xPos, yPos, platWidth, platHeight); //Now we draw the rectangle using the values entered in the constructor (see note above).
  }
}

//Please note - protagonist notKirby is also known as "Ball" throughout this code and commentary. Live free of perplexity!

//notKirby is a nested object made up of other objects, so originally his component parts had their own tabs. Once I integrated him into this game I decided to combine all the parts into one tab to keep character and the other game parts easily distinguishable.

class notKirby { //Make a class called "notKirby." This will create a nested object composed of various objects.
  float xPos, yPos, wide, tall; //These will be the default values for all other components of the face, to be modified in their cases for correct placement (code copied from the Face tab).
  int c; //Color of face.
  int c2 = (0xff2C27CB); //Color of pupil.
  float f = 90; //Blink frequency.
  float eyeDistance = 40 * resizer; //Distance from xPos of eye(s).
  float ang1 = 0;
  float ang2 = PI;
  float xVel = 3; //Modify horizontal position.
  float yVel = 0; //Modify vertical position.
  float speed_limit = 7.8f; //Limit vertical speed.
  float rebound = -3; //How much bounce is there?
  float grav = .3f; //Modify yVel to simulate gravity.
  float depth = 10; //Control how deep the ball can land on the platform (useful for collision detection).
  boolean jump = false; //Control when the ball can jump.
  boolean L, R = false; //Control when the ball can move.

  Eye eyes1;
  Face face1;
  Arm arm;

  notKirby(float _xPos, float _yPos, float _wide, float _tall, int _c) { //Uber-constructor in which we give the default parameters that will control almost everything.
    xPos = _xPos;
    yPos = _yPos;
    wide = _wide * resizer;
    tall = _tall * resizer;
    c = _c;
  }

  public void prep() { //Originally I placed the following initializations in the constructor above. But I got a Null Pointer Exception. So I thought maybe the notKirby object wasn't getting created (with its parameters entered through the constructor) soon enough before loading the nested objects that pull from its parameters. So I placed them in their own function, which runs after initializing the notKirby object on the main tab, and it worked!
    face1 = new Face();
    eyes1 = new Eye();
    arm = new Arm();
    /* //No longer using the individual constructors to give parameters, basing things instead on the notKirby constructor.
     face1 = new Face(200, 200, 175, 200, color(#FF08F3));
     eyes1  = new Eye(200, 170, 60, color (#2C27CB), 90); //x,y,s,c,f
     arm = new Arm(190, 230, 50, 50, 0, PI); //x, y, w, h, ang1, ang2
     */
  }

  public void display() {
    face1.display(xPos, yPos); //Thanks to Francisco for figuring out that I needed to pass the coordinates into the nested objects' display functions in order to update them with the changing positions.
    eyes1.display(xPos, yPos);
    arm.display(xPos, yPos);
  }

  public void updateBall() {
    if (jump == true) { //If jumping is allowed...
      yVel = -speed_limit; //...give the ball upward velocity. It's a jump!
      jump = false; //Immediately forbid jumping to prevent mid-air jumps.
    }
    if (R == true &&  xPos <= width-(wide / 2)) { //If rightward movement is allowed and the ball is not at the right edge of the screen...
      xPos += xVel; //...move the ball right based on the xVel.
    }
    if (L == true && xPos >= (wide / 2)) { //If leftward movement is allowed and the ball is not at the left edge of the screen...
      xPos -= xVel; //...move the ball left based on the xVel.
    }

    yPos += yVel; //Update yPos each frame with yVel.
    yVel += grav; //Update yVel each frame with grav.
    if (yVel > speed_limit) {
      yVel = speed_limit; //Impose terminal velocity to make collision detection easier.
    }

    if (yPos >= height - (tall / 2)) { //Did the ball hit the ground?
      if (yVel == speed_limit) { //If it was going fast enough...
        yVel = rebound; //...make it bounce a little.
      }
      else {
        yVel = 0; //Otherwise, bring it to rest (vertically).
      }
    }

    for (int i = 0; i < myLevels[currentLevel].myPlats.size(); i++) { //More collision detection. See the comments on the main tab for details. Same principles here.
      Platform myPlatform = myLevels[currentLevel].myPlats.get(i);
      if ((xPos + (wide / 2) >= myPlatform.xPos) && (xPos - (wide / 2) <= (myPlatform.xPos + myPlatform.platWidth))) { //At each value of i (aka ArrayList element in this case), is the ball's xPos within the width of the Platform at that element?
        if ((yPos + (tall / 2) >= myPlatform.yPos) && (yPos + (tall / 2) <= (myPlatform.yPos + depth))) { //Assuming we got a positive result above, is the ball's yPos within the upper part of the Platform at that element?
          if (yVel == speed_limit) { //The ball hit the platform, so change its velocity appropriately.
            yVel = rebound;
          }
          else {
            yVel = 0; //All of this is the same deal as when the ball hits the ground (see comments above).
          }
        }
        else if ((yPos - (tall / 2) >= (myPlatform.yPos + depth)) && (yPos - (tall / 2) <= (myPlatform.yPos + myPlatform.platHeight))) { //Ah, but what if the yPos is within the lower part of the Platform at that ArrayList element?
          yPos = (myPlatform.yPos + myPlatform.platHeight) + (tall / 2); //Set the yPos of the top of the ball (yPos - (tall / 2)) equal to the bottom of the platform (we must add (tall / 2) to the other side of the equation so yPos is isolated on the left). This prevents the ball from getting stuck within the platform when it reverses its velocity.
          yVel = (yVel - grav) * -1; //In that case the ball has hit the bottom of that Platform, so we reverse the direction (nullifying the gravity addition at this frame).
        }
      }
      //if (currentLevel == (myLevels.length - 1)) { //Make sure this is the last level.
      if (currentLevel == 11) {
        if (i == (myLevels[currentLevel].myPlats.size() - 1)) {
          if ((xPos + (wide / 2) >= myPlatform.xPos) && (xPos - (wide / 2) <= (myPlatform.xPos + myPlatform.platWidth))) { //Is the ball within the width of the last (and winning) Platform?
            if ((yPos + (tall / 2) >= myPlatform.yPos) && (yPos + (tall / 2) <= (myPlatform.yPos + depth))) { //If yes, is its vertical position within the upper part of that Platform?
              if (bounced == false) {
                bounced = true;
                msg = 6;
                next = true;
              }
            }
          }
        }
      }
      if ((yPos + (tall / 2) >= (myPlatform.yPos + depth)) && (yPos - (tall / 2) <= (myPlatform.yPos + myPlatform.platHeight - depth))) { //Glitch control! Here we prevent the ball from getting inside a platform by coming from the side (rather than the bottom or top). Pseudo code was extremely helpful to figure out how to say this. If the bottom of the ball is above the top of the platform, the ball is definitely not in the platform. If the top of the ball is below the bottom of the platform, the ball is definitely not in the platform. So we check if the ball's bottom is below the platform's top, and if the ball's top is above the platform's bottom. We also include the depth variable for both the top and bottom of the platform as a sort of margin of error - that is to account for the imprecision of the collision detection. It's the same thing as we did when detecting landing on a platform, except that we're applying it to the underside of the platform too, because otherwise if you jump into the bottom of a platform (as opposed to coming from the side) it doesn't detect the collision quickly enough and loads the behavior as if you had come from the side, with the result that the ball warps to the side of the platform.
        if ((xPos + (wide / 2) >= (myPlatform.xPos + (myPlatform.platWidth / 2))) && (xPos - (wide / 2) <= (myPlatform.xPos + myPlatform.platWidth))) { //Assuming yes to the above, we test once again to see if the ball's horizontal position is within the width of the platform. But, in order to control how movement is affected, we want to check if the ball is to the left or right side of the platform. So we split the test up into two sections - this first one checks if the ball is within the right half of the platform.
          xPos = (myPlatform.xPos + myPlatform.platWidth) + (wide / 2); //If yes to the above (the ball is in the right half of the platform), it seems pretty certain that the ball was coming from the right, so we set the ball's xPos equal to the right edge of the platform and account for the ball's width.
        }
        else if (((xPos + (wide / 2)) >= myPlatform.xPos) && ((xPos - (wide / 2)) < myPlatform.xPos + (myPlatform.platWidth / 2))) { //Part two of the width test checks to see if the ball is in the left half of the platform.
          xPos = myPlatform.xPos - (wide / 2); //If yes to the above (the ball is in the left half of the platform), it seems pretty certain that the ball was coming from the left, so we set the ball's xPos equal to the left edge of the platform and account for the ball's width. (The advantage of doing it this way is that we don't have to mess with the xVel value or the movement booleans). The result is the ball presses up against the edge of the platform like a wall and does not get stuck inside it!
        }
      }
    }
  }
}



//_________________________________________________________________________________________________________________________________________
//Arm class
//Please note - protagonist notKirby is also known as "Ball" throughout this code and commentary. Live free of perplexity!

class Arm { //Note I learned the hard way: any variables initialized here will only use the values from the first frame. If I need to update the variables, I must initialize them in a function into which I can pass the updated variables each frame.
  //xPos, yPos, width, height, start of arc (radians), end of arc (radians)
  float xPos;
  float yPos;
  //  float xPos = notKirby.xPos-(10 * resizer); //These two are no longer necessary (replaced with the two above) because they would pull only the first value of xPos and yPos from the notKirby object. We need to update each frame so the parts move together, so we update the display function below with the coordinates and initialize them there.
  //  float yPos = notKirby.yPos+(30 * resizer);
  float wide = notKirby.wide-(125 * resizer);
  float tall = notKirby.tall-(150 * resizer);
  float ang1 = notKirby.ang1;
  float ang2 = notKirby.ang2;

  /*
  Arm(float _xPos, float _yPos, float _wide, float _tall, float _ang1, float _ang2) { //Constructor - no longer needed because we are controlling all the variables through the main object, 'notKirby.'
   xPos = _xPos;
   yPos = _yPos;
   wide = _wide;
   tall = _tall;
   ang1 = _ang1;
   ang2 = _ang2;
   }
   */

  public void display(float _xPos, float _yPos) {
    xPos = _xPos-(10 * resizer);
    yPos = _yPos+(30 * resizer);
    noFill();
    stroke(0); //Color
    strokeWeight(2 * resizer); //Thickness of arc
    if (direction==true) { //Character is facing to the right.
      if (notKirby.yVel == 0) { //Character is on a surface.
        arc(xPos, yPos, wide, tall, ang1, ang2);  // Draw arm down and to the left.
      }
      else { //Character is in the air.
        arc(xPos, yPos, wide, tall, -ang2, ang1);  // Draw arm up and to the left.
      }
    }
    else { //Character is facing to the left.
      if (notKirby.yVel == 0) { //Character is on a surface.
        arc(xPos+(20 * resizer), yPos, wide, tall, ang1, ang2);  // Draw arm down and to the right.
      }
      else { //Character is in the air.
        arc(xPos+(20 * resizer), yPos, wide, tall, -ang2, ang1);  // Draw arm up and to the right.
      }
    }
  }
}



//_________________________________________________________________________________________________________________________________________
//Eye class
//Please note - protagonist notKirby is also known as "Ball" throughout this code and commentary. Live free of perplexity!

//Initial character code for separate parts Face, Eye and Mouth provided in class by Francisco, then modified by me.

class Eye { //Note I learned the hard way: any variables initialized here will only use the values from the first frame. If I need to update the variables, I must initialize them in a function into which I can pass the updated variables each frame.
  //posx, posy, size, blink frequency, color, distance from center of face
  float xPos;
  float yPos;
  //  float xPos = notKirby.xPos; //These two are no longer necessary (replaced with the two above) because they would pull only the first value of xPos and yPos from the notKirby object. We need to update each frame so the parts move together, so we update the display function below with the coordinates and initialize them there.
  //  float yPos = notKirby.yPos - (30  * resizer);
  float wide = notKirby.wide - (115 * resizer);
  float f = notKirby.f;
  int c = notKirby.c2;
  float eyeDistance = notKirby.eyeDistance;

  /*
  //constructor. It receives values from outside the class - no longer needed because we are controlling all the variables through the main object, 'notKirby.'
   Eye(float _xPos, float _yPos, float _wide, color _c, float _f) {
   //we copy the values coming from outside to our global variables
   xPos = _xPos;
   yPos = _yPos;
   wide = _wide;
   c = _c;
   f = _f;
   }
   */

  public void display(float _xPos, float _yPos) {
    xPos = _xPos;
    yPos = _yPos - (30  * resizer);
    //a small modulo trick to cycle and make the eyes blink
    if (frameCount % f < 8 ) {
      fill(0);
      if (direction==true) { //Character is facing to the right.
        ellipse (xPos+eyeDistance, yPos, wide, 2); //Draw the right eye blinking.
      }
      else { //Character is facing to the left.
        ellipse (xPos-eyeDistance, yPos, wide, 2); //Draw the left eye blinking.
      }
    }

    else {
      if (direction==true) { //Character is facing to the right.      
        //Draw right eye open.
        fill(255);
        ellipse (xPos+eyeDistance, yPos, wide, wide/2); //white of eye

        fill(c);
        noStroke();
        ellipse (xPos+(eyeDistance*1.4f), yPos, wide/3, wide/3);//iris

        fill(0);
        ellipse (xPos+(eyeDistance*1.5f), yPos, wide/5, wide/5);//pupil
      }
      else { //Character is facing to the left.
        //Draw left eye open.
        fill(255);
        ellipse (xPos-eyeDistance, yPos, wide, wide/2); //white

        fill(c);
        noStroke();
        ellipse (xPos-(eyeDistance*1.4f), yPos, wide/3, wide/3); //iris

        fill(0);
        ellipse (xPos-(eyeDistance*1.5f), yPos, wide/5, wide/5); //pupil
      }
    }
  }
}



//_________________________________________________________________________________________________________________________________________
//Face class
//Please note - protagonist notKirby is also known as "Ball" throughout this code and commentary. Live free of perplexity!

//Initial character code for separate parts Face, Eye and Mouth provided in class by Francisco, then modified by me.

class Face { //Note I learned the hard way: any variables initialized here will only use the values from the first frame. If I need to update the variables, I must initialize them in a function into which I can pass the updated variables each frame.
  //These will be the default values for all other components of the face, to be modified in their cases for correct placement.
  float xPos;
  float yPos;
  //  float xPos = notKirby.xPos; //These two are no longer necessary (replaced with the two above) because they would pull only the first value of xPos and yPos from the notKirby object. We need to update each frame so the parts move together, so we update the display function below with the coordinates and initialize them there.
  //  float yPos = notKirby.yPos;
  float wide = notKirby.wide;
  float tall = notKirby.tall;
  int c = notKirby.c;

  /*
  //constructor - no longer needed because we are controlling all the variables through the main object, 'notKirby.'
   Face(float _xPos, float _yPos, float _wide, float _tall, color _c) {
   xPos = _xPos;
   yPos = _yPos;
   wide = _wide;
   tall = _tall;
   c = _c;
   }
   */

  //draw
  public void display(float _xPos, float _yPos) {
    xPos = _xPos;
    yPos = _yPos;
    fill(c);
    noStroke();
    ellipse(xPos, yPos, wide, tall);
  }
}

  static public void main(String args[]) {
    PApplet.main(new String[] { "--bgcolor=#FFFFFF", "game" });
  }
}
